CREATE TABLE student_information (
	학생번호 number(38,0) NOT NULL,
	학생이름 varchar2(100) NOT NULL,
	주소 varchar2(100) NOT NULL,
	학과 varchar2(100) NOT NULL	
)

CREATE TABLE "record" (
	학생번호 number(38,0) NOT NULL,
	강좌이름 varchar2(100) NOT NULL,
	성적 float NOT NULL
)

CREATE TABLE "subject" (
	강좌이름 varchar2(100) NOT NULL,
	강의실 varchar2(100) NOT NULL
)

CREATE TABLE department (
	학과 varchar2(100) NOT NULL,
	학과사무실 varchar2(100) NOT NULL
)

INSERT INTO STUDENT_INFORMATION VALUES (2, '서길동', '강릉', '컴퓨터과')

INSERT INTO DEPARTMENT VALUES ('체육학과', '체육관101')

INSERT INTO "subject" VALUES ('테니스', '체육관 106')

INSERT INTO "record" VALUES (2, '데이터베이스', 4.5)

UPDATE STUDENT_INFORMATION 
SET 주소 = '울산'
WHERE 학생번호 = 5

SELECT * FROM STUDENT_INFORMATION si 
ORDER BY 학생번호

DELETE FROM STUDENT_INFORMATION si
WHERE 학생번호 = 2

DELETE FROM STUDENT_INFORMATION si 

SELECT si.학생번호 , si.학생이름 , d.학과 , d.학과사무실 , s.강좌이름 , s.강의실 , r.성적 
FROM STUDENT_INFORMATION si , DEPARTMENT d , "subject" s , "record" r 
WHERE si.학생번호 = r.학생번호 AND si.학과 = d.학과 AND s.강좌이름 = r.강좌이름 

-- 서브쿼리

SELECT * FROM STUDENT_INFORMATION si 
WHERE 학생번호 IN
(SELECT 학생번호 FROM "record" r WHERE 성적 = 4.5)

SELECT * FROM "record" r 
WHERE 강좌이름 = (SELECT 강좌이름 FROM "subject" s WHERE 강의실 = '공학관 301')

CREATE TABLE git_member (
	id varchar2(100),
	pw varchar2(100),
	name varchar2(100),
	tel number(38,0)
)

CREATE TABLE git_repository (
	"no" number(38,0),
	name varchar2(100),
	id varchar2(100)
)

CREATE TABLE repo_info (
	"no" number(38,0),
	name varchar2(100),
	code varchar2(100),
	issues number(38,0),
	"date" DATE
)

INSERT INTO GIT_MEMBER VALUES ('d', '78', '이', 014)

INSERT INTO GIT_REPOSITORY VALUES (5, 'java project', 'd')

INSERT INTO REPO_INFO VALUES (5, 'java 프로그램 만들기', 'java', 5, sysdate)

DELETE FROM REPO_INFO ri  
WHERE "no"  = '5'

UPDATE GIT_MEMBER 
SET pw = '90'
WHERE name = '이'

UPDATE REPO_INFO 
SET ISSUES = 0
WHERE "no" = 1

UPDATE REPO_INFO 
SET "date" = SYSDATE  

SELECT gm.ID , gm.NAME AS 사용자명 , gr.NAME AS repo명, ri.NAME AS 폴더명, ri.CODE AS 코드타입, ri.ISSUES , ri.UPLOAD  AS 업로드날짜
FROM GIT_MEMBER gm , REPO_INFO ri , GIT_REPOSITORY gr 
WHERE gm.ID = gr.ID AND gr."no" = ri."no" 