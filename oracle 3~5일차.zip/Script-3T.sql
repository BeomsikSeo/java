CREATE TABLE depart2 (
	id varchar2(100),
	name varchar2(100),
	instructor varchar2(100),
	constraints pk_dp2 PRIMARY KEY (id)
)

CREATE TABLE student2 (
	id varchar2(100),
	name varchar2(100),
	tel varchar2(100),
	depart_id varchar2(100)
)

ALTER TABLE STUDENT2 
ADD CONSTRAINTS pk_st2 
PRIMARY KEY (id)

ALTER TABLE STUDENT2 
ADD CONSTRAINTS fk_st2
FOREIGN KEY (depart_id)
REFERENCES depart2 (id)