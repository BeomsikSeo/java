CREATE TABLE "HR"."MEMBER" 
   (	"ID" VARCHAR2(100), 
	"PW" VARCHAR2(100), 
	"NAME" VARCHAR2(100), 
	"TEL" VARCHAR2(100)
	)
	
CREATE TABLE "HR"."BBS"
(	
	"no" VARCHAR2(100),
	"TITLE" VARCHAR2(100),
	"CONTENT" VARCHAR2(100),
	"WRITER" VARCHAR2(100)
)

CREATE TABLE PRODUCT(
	ID VARCHAR2(200),
	NAME VARCHAR2(200),
	CONTENT VARCHAR2(200),
	PRICE VARCHAR2(200),
	COMPANY VARCHAR2(200),
	IMG VARCHAR2(200)
)

-- 한줄복사 : 컨트롤 + 알트 + 화살표 아래

-- 한줄삭제 : 컨트롤 + D

-- 저장할 대상 : 엔티티(회원정보, 게시판, 상품), 엔티티간의 관계 : 회원이 상품을 주문하다(주문정보)
--           엔티티 + 관계 ==> 테이블로 만들자.!!!!!


CREATE TABLE orderlist (
	"no" VARCHAR2(100),
	member_id varchar2(100),
	product_id varchar2(100),
	total_count varchar2(100)
)

CREATE TABLE orderlist (
	"no" VARCHAR2(100),
	member_id varchar2(100),
	product_id varchar2(100),
	total_count varchar2(100)
)

CREATE TABLE depart (
	id VARCHAR2(100),
	name varchar2(100),
	instructor varchar2(100)
)

CREATE TABLE student (
	id VARCHAR2(100),
	name varchar2(100),
	tel varchar2(100),
	depart_id varchar2(100)
)

CREATE TABLE subject (
	id VARCHAR2(100),
	title varchar2(100),
	depart_id varchar2(100)
)

CREATE TABLE "HR"."BBS2" 
   ( "no" VARCHAR2(100), 
	"TITLE" VARCHAR2(100), 
	"CONTENT" VARCHAR2(100), 
	"WRITER" VARCHAR2(100), 
	 CONSTRAINT "BBS_PK22" PRIMARY KEY ("no"),
	 CONSTRAINT "FK_MEMBER22" FOREIGN KEY ("WRITER")
	 REFERENCES "HR"."MEMBER" ("ID")
	  )
	  
CREATE TABLE "HR"."BBS3" 
(	"no" VARCHAR2(100), 
	"TITLE" VARCHAR2(100), 
	"CONTENT" VARCHAR2(100), 
	"WRITER" VARCHAR2(100)
)

--pk제약조건 추가
ALTER TABLE HR.BBS3
ADD CONSTRAINT BBS3_PK PRIMARY KEY ("no")

--fk제약조건 추가
ALTER TABLE HR.BBS3 
ADD CONSTRAINT FK_MEMBER33 
FOREIGN KEY (WRITER) REFERENCES HR."MEMBER"(ID);

CREATE TABLE depart2 (
	id VARCHAR2(100),
	name varchar2(100),
	instructor varchar2(100),
	CONSTRAINT "DEPART2_PK" PRIMARY KEY (id)
)

CREATE TABLE student2 (
	id VARCHAR2(100),
	name varchar2(100),
	tel varchar2(100),
	depart_id varchar2(100)
)

ALTER TABLE student2
ADD CONSTRAINT studen2_pk
PRIMARY KEY (id)

ALTER TABLE STUDENT2 
ADD CONSTRAINT fk_depart22
FOREIGN KEY (depart_id) REFERENCES depart2(id)

--테이블 복사
CREATE TABLE member22
AS SELECT * FROM "MEMBER"

INSERT INTO member22 
VALUES ('banana3','banana3','banana3','banana3', sysdate)

SELECT * FROM member22	

INSERT INTO member22 
VALUES ('banana4','banana4','banana4','banana4', sysdate,default,'')

INSERT INTO bbs
VALUES (bbs_id_seq.nextval,'happy', 'happy day', 'ice')

SELECT * FROM bbs

INSERT INTO bbs
VALUES (bbs_id_seq.nextval,'happy2', 'happy day2', 'ice')

CREATE SEQUENCE pd_id_seq 
INCREMENT BY 1 
START WITH 1

CREATE TABLE product2 (
	id number(38, 0),
	name varchar2(100)
)

INSERT INTO PRODUCT2
VALUES (pd_id_seq.nextval,'computer')

SELECT * FROM product2

CREATE TABLE orderlist3 (
	id number(38, 0),
	title varchar2(100),
	price number(38, 0)
)

CREATE SEQUENCE or_seq
INCREMENT BY 1
START WITH 1

INSERT INTO orderlist3
VALUES (or_seq.nextval,'tomato',1000)

SELECT * FROM orderlist3

SELECT * FROM ORDERLIST3
ORDER BY id -- 오름차순

SELECT * FROM ORDERLIST3
ORDER BY id DESC -- 내림차순

SELECT * FROM ORDERLIST3
WHERE id >= 3
ORDER BY id DESC

CREATE TABLE DEPT (
	DEPTNO NUMBER(2),
	DNAME VARCHAR2(14 BYTE),
	LOC VARCHAR2(13 BYTE)
)

CREATE TABLE EMP (
	EMPNO NUMBER(4),
	ENAME VARCHAR2(10 BYTE),
	JOB VARCHAR2(9 BYTE),
	MGR NUMBER(4),
	HIREDATE DATE,
	SAL NUMBER(7,2),
	COMM NUMBER(7,2),
	DEPTNO NUMBER(2)
)

CREATE TABLE SALGRADE (
	GRADE NUMBER,
	LOSAL NUMBER,
	HISAL NUMBER
)

ALTER TABLE DEPT ADD (
CONSTRAINT PK_DEPT
PRIMARY KEY(DEPTNO));

ALTER TABLE EMP ADD (
CONSTRAINT PK_EMP
PRIMARY KEY(EMPNO));

ALTER TABLE EMP ADD (
CONSTRAINT FK_DEPTNO
FOREIGN KEY (DEPTNO)
REFERENCES DEPT (DEPTNO));

SELECT * FROM emp -- selection

SELECT deptno FROM emp -- projection

SELECT DISTINCT deptno FROM emp -- DISTINCT 중복제거

SELECT ename, sal * 12 AS yearsal FROM emp -- as를 안붙여주면 sal 컬럼명을 sal*12로 보여줌 (값들은 12를 곱한값을 보여줌)

SELECT * FROM EMP
ORDER BY sal -- 오름차순

SELECT * FROM EMP
ORDER BY sal DESC -- 내림차순

SELECT * FROM emp
WHERE deptno = 30
ORDER BY empno DESC -- ORDER BY 를 항상 마지막에.. 조건이 끝난 후 정렬

SELECT * FROM emp
WHERE NOT deptno = 30 -- depno가 30이 아닌 것
ORDER BY empno DESC

SELECT * FROM emp
WHERE deptno != 30 -- !는 NOT 과 같은 의미
ORDER BY empno DESC

SELECT * FROM emp
WHERE deptno = 30 AND job = 'SALESMAN'

SELECT * FROM emp
WHERE deptno = 30 or job = 'SALESMAN'

SELECT * FROM emp
WHERE sal >= 3000

SELECT * FROM EMP
WHERE sal != 3000

SELECT * FROM emp 
WHERE job IN ('SALESMAN', 'MANAGER') -- or의 의미
ORDER BY JOB 

SELECT * FROM emp 
WHERE job NOT IN ('SALESMAN', 'MANAGER') -- 둘 다 안 들어 가는 것
ORDER BY JOB 

SELECT * FROM emp 
WHERE sal BETWEEN 2000 AND 3000 -- 사이값
ORDER BY empno 

SELECT * FROM emp 
WHERE sal NOT BETWEEN 2000 AND 3000 -- 사이에 속하지 않는 값
ORDER BY empno 

SELECT * FROM emp 
WHERE ename LIKE '_L%' -- L 앞에 한자리 있는 것, 뒤에는 아무거나

SELECT * FROM emp 
WHERE ename NOT LIKE '_L%'

SELECT * FROM emp 
WHERE comm IS NULL 

SELECT * FROM emp 
WHERE comm IS not NULL 

CREATE TABLE dept_temp2
AS
SELECT * FROM DEPT

SELECT * FROM dept_temp2

UPDATE DEPT_TEMP2
SET LOC = 'SEOUL'

UPDATE dept_temp2 
SET dname = 'DATABASE', loc = 'BUSAN'
WHERE deptno = 40

DELETE FROM DEPT_TEMP2
WHERE dname = 'SALES'

SELECT * FROM dept_temp2

-- 1. price는 number(oracle), int(mysql)
-- 2. price로 내림차순 정렬하여 전체컬럼 검색
SELECT * FROM PRODUCT
ORDER BY price DESC

-- 3. company로 오름차순 정렬하여 제품의 이름, 내용, 가격 검색
SELECT name, content, price FROM product
ORDER BY company

-- 4. company의 목록을 검색(중복제거)
SELECT DISTINCT company FROM product 

-- 5. 각 신발을 5개씩 주문했을 때의 가격을 price5라고 항목명을 지정하여 출력
SELECT price * 5 AS price5 FROM product

-- 6. price가 5000인 제품명과 회사명
SELECT name, company FROM product 
WHERE price = 5000

-- 7. price가 3000과 6000 사이인 제품명과 가격, 회사명 검색
SELECT name, company FROM product 
WHERE price BETWEEN 3000 and 6000

-- 8. 회사명이 c100이 아닌 회사명과 제품명
SELECT company, name FROM product 
WHERE NOT company = 'c100'

-- 9. 회사명이 c100, c200인 제품명과 가격
SELECT name, price FROM product 
WHERE company = 'c100' OR company = 'c200'

-- 10. 제품명에 4로 끝나는 제품의 전체 정보 검색
SELECT * FROM product 
WHERE name LIKE '%4'

-- 11. 제품내용에 food를 포함하는 제품의 전체 정보 검색
SELECT * FROM product 
WHERE content LIKE '%food%'

-- 12. price가 5000원인 제품의 content를 품절로 수정
UPDATE product
SET content = '품절'
WHERE price = 5000

SELECT * FROM product

-- 13. id가 100, 102번 제품의 img를 o.png로, price를 10000으로 수정
UPDATE product 
SET img = 'o.png', price = 10000
WHERE id = '100' OR id = '102'

-- 14. 회사명이 c100인 경우 모든 정보 삭제
DELETE FROM product 
WHERE company = 'c100'

SELECT * FROM product

-- 15. 테이블의 모든 정보 삭제
DELETE FROM product

-- 16. 테이블 삭제
DROP TABLE product